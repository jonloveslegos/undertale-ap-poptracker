# Variants

Variants can override many files, for example: items, maps, locations, layouts and scripts.

You override file just by put them in the same place and with the name inside the variants folder.
Example: you want to overide ``layouts/tracker.json`` in the ``var_itemsonly`` variant -> place the file at ``var_itemsonly/locations/tracker.json``

In most cases overriding layouts is all you need so thats what I've done in this example.